import{r,i as a,j as t}from"./index-870b29dd.js";var e={},u=a;Object.defineProperty(e,"__esModule",{value:!0});var v=e.default=void 0,d=u(r()),o=t,i=(0,d.default)((0,o.jsx)("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"}),"Add");v=e.default=i;export{v as d};
//# sourceMappingURL=Add-8d57b3d1.js.map
