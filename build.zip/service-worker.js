/* eslint-disable no-undef */
importScripts(
  'https://storage.googleapis.com/workbox-cdn/releases/3.2.0/workbox-sw.js',
)

if (workbox) {
  //workbox solo existe en el scope del serviceWorker
  console.log('Workbox loaded!')
} else {
  console.log(`Can't load Workbox`)
}

workbox.core.setCacheNameDetails({
  prefix: 'vectro-lite',
  suffix: 'v1',
  precache: 'precache-cache',
  runtime: 'runtime-cache',
})

workbox.routing.registerRoute(
  /\.(?:js|css)$/, // Todos los archivos con extensión js o css
  workbox.strategies.cacheFirst({
    cacheName: workbox.core.cacheNames.precache, // nombre de la cache donde queremos guardar el recurso
  }),
)
